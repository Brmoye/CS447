<!DOCTYPE html>
<html lang="en">
<head>
    <title>Hats</title>
    <meta charset="UTF-8">
    <style>
        body { background-color: lightgrey; text-align: center; }
        form { padding: 2em; }
        input { padding: 1em; margin-bottom: 1em;}
        table { margin-left: 35%; border: solid 2px black; }
    </style>
<body>
    <h1>Hats Database</h1>

