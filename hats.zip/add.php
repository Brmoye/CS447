<?php
    require("header.php");

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        processForm();
    } else {
        displayForm();
    }

    require("footer.php");

//----------------------------------------
function displayForm() {

    echo <<<HTMLFORM
	<p style="text-align: left;"><a href="index.html">Back</a></p>

	<form method="POST" action="add.php">
	    <label for="color">Hat color:</label>
	    <input type="input" name="color" required><br>
	    <label for="size">Hat size:</label>
	    <input type="input" name="size" required><br>
	    <label for="type">Hat type:</label>
	    <input type="input" name="type" required><p>
	    <input type="button" value="Add Hat">
	</form>
HTMLFORM;

}

//----------------------------------------
function processForm() {

    // ADD YOUR CODE HERE
    // -----------------------
    // Connect to the database
    // Run your query
    // Display (echo) a status message. For example "OK" or "Error"
    // Display a link back to index.html
    // Disconnect (close) the database connection

}
 
?>
