<?php
    require("header.php");

    displayHats();

    require("footer.php");

//----------------------------------------
function displayHats() {

    // ADD YOUR CODE HERE
    // -----------------------
    // Connect to the database
    // Run your query
    // Display a link back to index.html
    // Disconnect (close) the database connection

}
 
?>
